package testBrochain;

import com.zchz.brop.brochain.crypto.Credentials;
import com.zchz.brop.brochain.protocol.Brop;
import com.zchz.brop.brochain.protocol.http.HttpService;

import java.io.IOException;

public class testCrud {
    public static void main(String[] args) throws Exception {
        String newregion_id="0x0000000000000023000000006472084b00000000";
        // BROCHAIN�������ڵ��ַ������ǵ��޸�
        String nodeUrl = "http://192.168.15.131:4000";
        // Ĭ����Կ
        String privateKey="B08820479C40797BA8452368595CDC6D7207580828D74AE1C9AA9F0E50FA71BD";

        // ʹ��local���ܻ����콻��ǩ��Credentials
        Credentials credentials = Credentials.createOfPrivateKey(privateKey);
        // �������Brop
        Brop brop = Brop.build(new HttpService(nodeUrl));
        System.out.println(brop.getChainState().send().getResult());

        String crudAddr="0x0da4833236108f8896cc3588bc5a48e9b0cfb9e0";
        CURD curd=CURD.load(newregion_id,crudAddr,brop,credentials);
        //CURD curd=CURD.deploy(newregion_id,brop,credentials).send();
        System.out.println("ContractAddr: " +curd.getContractAddress());

        curd.insert("liu111","0x1").send();
        String tk2 = curd.get("liu111").send();
        System.out.println(tk2);
    }
}
