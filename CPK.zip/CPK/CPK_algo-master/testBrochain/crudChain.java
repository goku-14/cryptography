package testBrochain;

import com.zchz.brop.brochain.crypto.Credentials;
import com.zchz.brop.brochain.protocol.Brop;
import com.zchz.brop.brochain.protocol.http.HttpService;
import org.example.CURD;

public class crudChain {
    public CURD crudChain() throws Exception {
        String newregion_id="0x0000000000000023000000006472084b00000000";
        // BROCHAIN�������ڵ��ַ������ǵ��޸�
        String nodeUrl = "http://192.168.15.136:4000";
        // Ĭ����Կ
        String privateKey="B08820479C40797BA8452368595CDC6D7207580828D74AE1C9AA9F0E50FA71BD";

        // ʹ��local���ܻ����콻��ǩ��Credentials
        Credentials credentials = Credentials.createOfPrivateKey(privateKey);
        // �������Brop
        Brop brop = Brop.build(new HttpService(nodeUrl));
        System.out.println(brop.getChainState().send().getResult());

        String crudAddr="0x0da4833236108f8896cc3588bc5a48e9b0cfb9e0";
        CURD curd= CURD.load(newregion_id,crudAddr,brop,credentials);
        //CURD curd=CURD.deploy(newregion_id,brop,credentials).send();
        System.out.println("ContractAddr: " +curd.getContractAddress());
        return curd;

        // =curd.insert("1234","0x1324324").send();
        //curd.update("456","0x2").send();
        //BrochainTransactionReceipt receipt=curd.remove("456").send();
        //System.out.println(curd.getEntityRemovedEvents(receipt));
        //curd.update("123","0x2");
        //String tk1 = curd.get("456").send();
        //System.out.println(tk1);
        //System.out.println(receipt);
        //Tuple2<String, String> result = crudApp.getEntity("123").send();

        //String tk2 = curd.get("1234").send();
        //System.out.println(tk2);

        //tk1 = curd.get("456").send();
        //System.out.println(tk1);
    }
}