package ecc.elliptic;

public class NoCommonMotherException extends Exception{

    public String getErrorString(){
	return "NoCommonMother";
    }

}
