package socket;
import ecc.elliptic.TestECCrypto;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class fileSocketServer {
        private static final int PORT = 44444;


        public static void main(String[] args) {
            try {
                ServerSocket serverSocket = new ServerSocket(PORT);
                System.out.println("Server started. Listening on port: " + PORT);

                while (true) {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("Client connected: " + clientSocket.getInetAddress().getHostAddress());

                    OutputStream outputStream = clientSocket.getOutputStream();

                    //TestECCrypto test1 = new TestECCrypto();
                    //test1.generation();
                    String FILE1_PATH = "/home/auth/Java/CPK_algo-master/sKey.txt";
                    String FILE2_PATH = "/home/auth/Java/CPK_algo-master/pKey.txt";

                    // Send file1
                    sendFile(outputStream, FILE1_PATH);

                    // Send file2
                    sendFile(outputStream, FILE2_PATH);

                    outputStream.close();
                    clientSocket.close();
                    System.out.println("Files sent to client.");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private static void sendFile(OutputStream outputStream, String filePath) throws IOException {
            File file = new File(filePath);
            FileInputStream fileInputStream = new FileInputStream(file);

            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            fileInputStream.close();
        }

}
