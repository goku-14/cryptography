package socket;
import ecc.Key;
import ecc.elliptic.ECKey;

import java.io.*;
import java.net.Socket;

public class fileSocketClient {
    private static final String SERVER_IP = "192.168.114.136";
    private static final int SERVER_PORT = 44444;
    private static final String SAVE_PATH1 = "/home/auth/1.txt";
    private static final String SAVE_PATH2 = "/home/auth/2.txt";

    public static void main(String[] args) {
        try {

            Socket socket = new Socket(SERVER_IP, SERVER_PORT);

            long start1 = System.currentTimeMillis();



            System.out.println("Connected to server,back sk,pk");

            InputStream inputStream = socket.getInputStream();

            // Receive file1
            receiveFile(inputStream, SAVE_PATH1);

            // Receive file2
            receiveFile(inputStream, SAVE_PATH2);
            long end1 = System.currentTimeMillis();
            System.out.println("��Կʱ�ӣ�"+(end1-start1)+"ms");

            inputStream.close();
            socket.close();
            System.out.println("Files received from server.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private static void receiveFile(InputStream inputStream, String savePath) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(savePath);

        byte[] buffer = new byte[8192];
        int bytesRead;
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            fileOutputStream.write(buffer, 0, bytesRead);
        }

        fileOutputStream.close();
    }

}
