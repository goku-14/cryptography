package socket;
import ecc.CryptoSystem;
import ecc.Key;
import ecc.elliptic.*;
import org.example.CURD;
import testBrochain.crudChain;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class testCrudChain {
    static volatile List<Map> result;
    public static void main(String args[]) throws Exception {

        Key[] finalKeys = new generationKey().generationKey();

        //��ȡ���ܺ�Լ��ַ
        crudChain crudchain = new crudChain();
        CURD crud = crudchain.crudChain();

        //��Կ����
        crud.insert("liu",finalKeys[1].toString());
        System.out.println("��Կ�����ɹ�");

        //���ϲ�ѯ
        crud.insert("liu",finalKeys[1].toString());
        System.out.println("��ѯ���Ϊ��"+crud.get("liu").send());




    }

}