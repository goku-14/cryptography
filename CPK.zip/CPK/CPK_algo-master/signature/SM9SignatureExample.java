package signature;
import ecc.elliptic.TestECCryptoLIU;
import org.apache.poi.ss.formula.functions.T;
import org.bouncycastle.asn1.gm.GMNamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.generators.ECKeyPairGenerator;
import org.bouncycastle.crypto.params.ECDomainParameters;
import org.bouncycastle.crypto.params.ECKeyGenerationParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.crypto.signers.SM2Signer;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;
import java.security.Security;
import java.security.SecureRandom;
import ecc.*;
public class SM9SignatureExample {
    public static void main(String[] args) {
        Security.addProvider(new BouncyCastleProvider());
        // ��ȡSM9���߲���
        X9ECParameters x9ECParameters = GMNamedCurves.getByName("sm2p256v1");
        ECDomainParameters curveParams = new ECDomainParameters(x9ECParameters.getCurve(), x9ECParameters.getG(), x9ECParameters.getN());


        try {
            // ����SM9��Կ��
            long start3 = System.currentTimeMillis();
            ECKeyPairGenerator keyPairGenerator = new ECKeyPairGenerator();
            keyPairGenerator.init(new ECKeyGenerationParameters(curveParams, new SecureRandom()));
            AsymmetricCipherKeyPair keyPair = keyPairGenerator.generateKeyPair();
            ECPrivateKeyParameters privateKey = (ECPrivateKeyParameters) keyPair.getPrivate();
            ECPublicKeyParameters publicKey = (ECPublicKeyParameters) keyPair.getPublic();

            long end3 = System.currentTimeMillis();
            System.out.println("���ɹ�˽Կ��ʱ:" + (end3 - start3));

            // Ҫǩ��������
            byte[] data = "Hello!".getBytes();

            // ǩ��
            long start1 = System.currentTimeMillis();
            SM2Signer signer = new SM2Signer();
            signer.init(true, privateKey);
            signer.update(data, 0, data.length);
            byte[] signature = signer.generateSignature();
            long end1 = System.currentTimeMillis();

            System.out.println("ǩ����ʱ:" + (end1 - start1));

            // ��ӡǩ�����
            System.out.println("Signature: " + Hex.toHexString(signature));

            // ��֤ǩ��
            long start2 = System.currentTimeMillis();
            signer.init(false, publicKey);
            signer.update(data, 0, data.length);
            boolean verified = signer.verifySignature(signature);
            long end2 = System.currentTimeMillis();
            System.out.println("��֤ǩ����ʱ:" + (end2 - start2));

            // ��ӡ��֤���
            System.out.println("Verified: " + verified);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
