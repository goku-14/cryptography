package simulation;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class jascTest {
    public static void main(String[] args) throws NoSuchAlgorithmException {
        randomString rs = new randomString();
        String originalString1 = rs.usingUUID();
        String originalString2 = rs.usingUUID();
        byte[] result1 = {};
        byte[] result2 = {};
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        messageDigest.update(originalString1.getBytes());
        result1 = messageDigest.digest();
        messageDigest.update(originalString2.getBytes());
        result2 = messageDigest.digest();

        StringBuilder hexString1 = new StringBuilder();
        StringBuilder hexString2 = new StringBuilder();
        StringBuilder combin = new StringBuilder();

        for (byte b : result1) {
            hexString1.append(String.format("%02X", b));
        }
        for (byte b : result2) {
            hexString2.append(String.format("%02X", b));
        }

        String str1 = hexString1.toString();
        String str2 = hexString2.toString();

        BigInteger h1 = new BigInteger(str1, 16);
        BigInteger ks = new BigInteger(str2,16);
        long[] result = new long[20000];
        for (int i = 0; i < 100; i++) {
            long start = System.nanoTime();
            String cob = str1 + str2;
            messageDigest.update(cob.getBytes());
            BigInteger t1 = h1.add(ks);
            BigInteger t2 = ks.divide(t1);
            BigInteger sk = t2.multiply(new BigInteger("5AC635D8"+"AA3A93E7"+"B3EBBD55"+"769886BC"+
                    "651D06B0"+"CC53B0F6"+"3BCE3C3E"+"27D2604B", 16));
            long end = System.nanoTime();
            result[i] = end - start;
        }
        long sum = 0;
        for (int i = 0; i < 100; i++) {
            sum += result[i];
        }
        System.out.println("��ϣʱ�䣺" + (double)sum/100000000);

    }
}
