package simulation.OurScheme;

import ecc.CryptoSystem;
import ecc.Key;
import ecc.elliptic.*;
import simulation.randomString;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class updateAID {
    public static void main(String[] args) throws NoSuchAlgorithmException, InsecureCurveException, NoCommonMotherException {
        randomString rs = new randomString();
        String originalString1 = rs.usingUUID();
        String originalString2 = rs.usingUUID();
        byte[] result1 = {};
        byte[] result2 = {};
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        messageDigest.update(originalString1.getBytes());
        result1 = messageDigest.digest();
        messageDigest.update(originalString2.getBytes());
        result2 = messageDigest.digest();
        StringBuilder hexString1 = new StringBuilder();
        StringBuilder hexString2 = new StringBuilder();
        StringBuilder combin = new StringBuilder();

        for (byte b : result1) {
            hexString1.append(String.format("%02X", b));
        }
        for (byte b : result2) {
            hexString2.append(String.format("%02X", b));
        }
        String str1 = hexString1.toString();
        String str2 = hexString2.toString();
        EllipticCurve ec3 = new EllipticCurve(new secp256r1());
        CryptoSystem cs3 = new ECCryptoSystem(ec3);
        Key[] cb3 = new Key[100000];

//        for (int i = 0; i < 256; i++) {
//            cb3[i] = (ECKey) cs3.generateKey();
//        }


        long[] result = new long[200000];
        for (int j = 0; j < 100; j++) {
            long start = System.nanoTime();
            for (int i = 0; i < 40; i++) {
                String cob = str1 + str2;
                messageDigest.update(cob.getBytes());
                messageDigest.digest();
//                ECKey tempCombine3 = (ECKey) cb3[0];
//                for (int k = 0; k < 256; k++) {
//                    tempCombine3 = tempCombine3.SKadd((ECKey) cb3[k]);
//                }
            }
            long end = System.nanoTime();
            result[j] = end - start;
        }

        long sum = 0;
        for (int i = 0; i < 100; i++) {
            sum += result[i];
        }
        System.out.println("��ϣʱ�䣺" + (double)(sum)/100000000);
    }
}
