package simulation.OurScheme;

import jdk.nashorn.internal.ir.debug.ObjectSizeCalculator;
import simulation.randomString;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashSet;
import java.util.Set;

public class DynamicRSAAccumulator {
    private BigInteger accumulator;
    private BigInteger modulus;
    private MessageDigest digest;
    private Set<String> elements;

    public DynamicRSAAccumulator() throws NoSuchAlgorithmException {
        accumulator = BigInteger.ONE;
        modulus = BigInteger.ONE;
        digest = MessageDigest.getInstance("SHA-256");
        elements = new HashSet<>();
    }

    public void addToAccumulator(String value) {
        if (elements.contains(value)) {
            return; // Ԫ���Ѵ��ڣ����ظ�����
        }

        byte[] hash = digest.digest(value.getBytes());
        BigInteger element = new BigInteger(1, hash);
        accumulator = accumulator.multiply(element).mod(modulus);
        elements.add(value);
    }

    public void removeFromAccumulator(String value) {
        if (!elements.contains(value)) {
            return; // Ԫ�ز����ڣ�����ɾ��
        }

        byte[] hash = digest.digest(value.getBytes());
        BigInteger element = new BigInteger(1, hash);
        BigInteger inverse = element.modInverse(modulus);
        accumulator = accumulator.multiply(inverse).mod(modulus);
        elements.remove(value);
    }

    public boolean isInAccumulator(String value) {
        byte[] hash = digest.digest(value.getBytes());
        BigInteger element = new BigInteger(1, hash);
        BigInteger result = element.modPow(accumulator, modulus);
        return result.equals(BigInteger.ONE);
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        DynamicRSAAccumulator accumulator = new DynamicRSAAccumulator();

        // ����Ԫ�ص��ۼ���
        long sum = 0;
        randomString rs = new randomString();
        for (int i = 0; i < 400; i++) {
            long start = System.currentTimeMillis();
            for (int j = 0; j < 500; j++) {
                accumulator.addToAccumulator(rs.usingUUID());
            }
            long end = System.currentTimeMillis();
            sum += (end - start);
        }
        System.out.println("����ʱ��Ϊ��" + (sum)/400);







        accumulator.addToAccumulator("Bob");
        accumulator.addToAccumulator("Charlie");

        // ���Ԫ���Ƿ����ۼ�����
        long start1 = System.currentTimeMillis();
        System.out.println("Alice in accumulator: " + accumulator.isInAccumulator("Alice"));
        long end1 = System.currentTimeMillis();
        System.out.println("��ѯʱ��Ϊ��" + (end1 - start1));
        // ��� true
        System.out.println("Eve in accumulator: " + accumulator.isInAccumulator("Eve")); // ��� false

        // ���ۼ�����ɾ��Ԫ��
        long start2 = System.currentTimeMillis();
        accumulator.removeFromAccumulator("Bob");
        long end2 = System.currentTimeMillis();
        System.out.println("ɾ��ʱ��Ϊ��" + (end2 - start2));

        // �ٴμ��Ԫ���Ƿ����ۼ�����
        System.out.println("Bob in accumulator: " + accumulator.isInAccumulator("Bob")); // ��� false
    }
}
