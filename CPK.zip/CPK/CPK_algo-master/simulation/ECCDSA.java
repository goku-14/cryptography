package simulation;

import sun.security.ec.ECPrivateKeyImpl;
import sun.security.ec.ECPublicKeyImpl;
import java.math.BigInteger;
import java.security.*;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECFieldFp;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.EllipticCurve;
import java.util.HashMap;
import java.util.Map;

public class ECCDSA {
    private static final String KEY_ALGORITHM="EC";
    private static final int KEY_SIZE = 256;
    private static final String SIGNATURE_ALGORITHM = "SHA512withECDSA";

    //������Կ��,��ȡ��Կ����
    public static  Map<String,Object> initKey() throws Exception{
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(KEY_ALGORITHM);
        //��ʼ����Կ��������
        keyPairGenerator.initialize(KEY_SIZE);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        //�õ���Կ��˽Կ
        ECPublicKey publicKey = (ECPublicKey) keyPair.getPublic();
        ECPrivateKey privateKey = (ECPrivateKey) keyPair.getPrivate();
        //��ȡ˽ԿD
        BigInteger D = privateKey.getS();
        //�õ���Կ�ĺ�������
        BigInteger publicKeyX= publicKey.getW().getAffineX();
        BigInteger publicKeyY= publicKey.getW().getAffineY();
        //�õ�������Բ���ߵĲ���a,b
        java.security.spec.ECParameterSpec ecParams = privateKey.getParams();
        BigInteger curveA = ecParams.getCurve().getA();
        BigInteger curveB = ecParams.getCurve().getB();
        //��ȡ����Բ�����ֶε����� qq
        ECFieldFp fieldFp = (ECFieldFp) ecParams.getCurve().getField();
        BigInteger q = fieldFp.getP();
        //��ȡ��Բ�Ļ����x,yֵ
        BigInteger coordinatesX = ecParams.getGenerator().getAffineX();
        BigInteger coordinatesY =  ecParams.getGenerator().getAffineY();
        //����Ľ�
        BigInteger coordinatesG = ecParams.getOrder();
        //��ȡ������
        int h = ecParams.getCofactor();

        Map<String, Object> initKeyMap = new HashMap<String,Object>();
        //��Բ���߲���A,B
        initKeyMap.put("A",curveA);
        initKeyMap.put("B",curveB);
        //����Q
        initKeyMap.put("Q",q);
        //G�������
        initKeyMap.put("X",coordinatesX);
        initKeyMap.put("Y",coordinatesY);
        //NΪG��Ľ�
        initKeyMap.put("N",coordinatesG);
        //HΪ������
        initKeyMap.put("H",h);
        //��ȡ˽Կ
        initKeyMap.put("D",D);
        //��ȡ��Կ�������
        initKeyMap.put("PUBKEY_X",publicKeyX);
        initKeyMap.put("PUBKEY_Y",publicKeyY);
        return initKeyMap;
    }

    //DATA�����ݣ�Q�Ǵ�����q��A��BΪ��Բ���߲���a,b��GΪ���㣬NΪ��G�Ľף�H��������,X,Y�ǻ�������꣬PUBKEY_X,PUBKEY_Y�ǹ�Կ(DG)�����꣬D�������˽Կ

    public static KeyPair generateKey(BigInteger Q, BigInteger A, BigInteger B, BigInteger N, int H, BigInteger X, BigInteger Y, BigInteger PUBKEY_X, BigInteger PUBKEY_Y, BigInteger D) throws Exception{
        //��������ָ��ֵ����Բ���������
        ECParameterSpec ecParameterSpec = new ECParameterSpec(new EllipticCurve(new ECFieldFp(Q),A,B),new ECPoint(X,Y),N,H);
        ECPublicKey publicKey = new ECPublicKeyImpl(new ECPoint(PUBKEY_X,PUBKEY_Y),ecParameterSpec);
        ECPrivateKey privateKey = new ECPrivateKeyImpl(D,ecParameterSpec);
        return new KeyPair(publicKey,privateKey);
    }
    public static   byte[] sign(byte[] data,PrivateKey privateKey) throws Exception {
        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
        signature.initSign(privateKey);
        signature.update(data);
        return signature.sign();
    }


    public static boolean verify(byte[] data,PublicKey publicKey, byte[] sign) throws Exception {
        Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
        signature.initVerify(publicKey);
        signature.update(data);
        return signature.verify(sign);
    }
    public static void main(String[] args) throws Exception {
        randomString rd = new randomString();
        ECCDSA ecc = new ECCDSA();
        int round = 1;
        int count = 1;
        int sum1 = 0;
        int sum2 = 0;
        for (int k = 0; k < count; k += 5) {
            for (int j = 0; j < round; j++) {

                for (int i = 0; i <= k; i++) {
                    String str = rd.usingUUID();
                    long start = System.currentTimeMillis();
                    Map<String,Object> map = ecc.initKey();

                    KeyPair key = ecc.generateKey((BigInteger) map.get("Q"),(BigInteger)map.get("A"),(BigInteger)map.get("B"),(BigInteger)map.get("N"), (Integer) map.get("H"),(BigInteger)map.get("X"),(BigInteger)map.get("Y"),(BigInteger)map.get("PUBKEY_X"),(BigInteger)map.get("PUBKEY_Y"),(BigInteger)map.get("D"));
                    long end = System.currentTimeMillis();
                    byte[] sign = ecc.sign(str.getBytes(),key.getPrivate());
                    boolean flag = ecc.verify(str.getBytes(), key.getPublic(),sign);

                    sum1 += (end - start);
                }

                for (int i = 0; i <= k; i++) {
                    String str = rd.usingUUID();

                    Map<String,Object> map = ecc.initKey();
                    KeyPair key = ecc.generateKey((BigInteger) map.get("Q"),(BigInteger)map.get("A"),(BigInteger)map.get("B"),(BigInteger)map.get("N"), (Integer) map.get("H"),(BigInteger)map.get("X"),(BigInteger)map.get("Y"),(BigInteger)map.get("PUBKEY_X"),(BigInteger)map.get("PUBKEY_Y"),(BigInteger)map.get("D"));
                    long start = System.currentTimeMillis();
                    byte[] sign = ecc.sign(str.getBytes(),key.getPrivate());
                    boolean flag = ecc.verify(str.getBytes(), key.getPublic(),sign);
                    long end = System.currentTimeMillis();
                    sum2 += (end - start);
                }
            }
            System.out.println("�û����û�����Ϊ" + k + "ʱ��ʱΪ" + (sum1/round));
            System.out.println("������û�����Ϊ" + k + "ʱ��ʱΪ" + (sum2/round));
            sum1 = 0;
            sum2 = 0;
        }
    }




}

