package simulation;

import java.util.UUID;

public class randomString {
    public static String usingUUID() {
        UUID randomUUID = UUID.randomUUID();
        return randomUUID.toString().replaceAll("-", "");
    }
}
