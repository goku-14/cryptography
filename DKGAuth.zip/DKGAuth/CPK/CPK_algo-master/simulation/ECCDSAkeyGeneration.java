package simulation;

import javax.xml.bind.DatatypeConverter;
import java.security.*;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

/**
 * ECCDSA��ǩ��ǩ������
 * @author Administrator
 *
 */
public class ECCDSAkeyGeneration {

    private static final String SIGNALGORITHMS = "SHA256withECDSA";
    private static final String ALGORITHM = "EC";
    private static final String SECP256K1 = "secp256k1";


    public static void main(String[] args) throws Exception {
        String data="��Ҫǩ��������";
        int count = 50;
        int round = 100;
        long sum1 = 0,sum2 = 0;
        for (int k = 0; k <= count; k += 5) {
            for (int j = 0; j < round; j++) {
                long start = System.currentTimeMillis();
                //�û���
                for (int i = 0; i < k; i++) {
                    KeyPair keyPair1 = getKeyPair();
                    PublicKey publicKey1 = keyPair1.getPublic();
                    PrivateKey privateKey1 = keyPair1.getPrivate();
                    //��Կת16�����ַ���
                    String publicKey = HexUtil.encodeHexString(publicKey1.getEncoded());
                    String privateKey = HexUtil.encodeHexString(privateKey1.getEncoded());
                    //System.out.println("���ɹ�Կ��"+publicKey);
                    //System.out.println("����˽Կ��"+privateKey);
                    //16�����ַ���ת��Կ����
                    PrivateKey privateKey2 = getPrivateKey(privateKey);
                    PublicKey publicKey2 = getPublicKey(publicKey);
                    //��ǩ��ǩ
                    String signECDSA = signECDSA(privateKey2, data);
                    boolean verifyECDSA = verifyECDSA(publicKey2, signECDSA, data);
                }
                long end = System.currentTimeMillis();
                sum1 += (end-start);
            }
            System.out.println("�û���Ϊ"+ k + "����Կ���ɺ�ǩ��ʱ��Ϊ" + sum1/round);
            sum1 = 0;

        }
        KeyPair keyPair1 = getKeyPair();
        PublicKey publicKey1 = keyPair1.getPublic();
        PrivateKey privateKey1 = keyPair1.getPrivate();
        //��Կת16�����ַ���
        String publicKey = HexUtil.encodeHexString(publicKey1.getEncoded());
        String privateKey = HexUtil.encodeHexString(privateKey1.getEncoded());
        //System.out.println("���ɹ�Կ��"+publicKey);
        //System.out.println("����˽Կ��"+privateKey);
        //16�����ַ���ת��Կ����
        PrivateKey privateKey2 = getPrivateKey(privateKey);
        PublicKey publicKey2 = getPublicKey(publicKey);
        String signECDSA = signECDSA(privateKey2, data);
        //System.out.println("��ǩ�����"+verifyECDSA);
        //����˲�
        for (int k = 0; k <= count; k += 5) {
            for (int j = 0; j < round; j++) {
                long start = System.currentTimeMillis();
                for (int i = 0; i < k; i++) {
                    String signECDSA1 = signECDSA(privateKey2, data);
                    boolean verifyECDSA1 = verifyECDSA(publicKey2, signECDSA, data);
                }
                long end = System.currentTimeMillis();
                sum2 += (end-start);
            }
            System.out.println("������û���Ϊ"+ k + "��ǩ������ǩʱ��Ϊ" + sum2/round);
            sum2 = 0;
        }



    }

    /**
     * ��ǩ
     * @param privateKey ˽Կ
     * @param data ����
     * @return
     */
    public static String signECDSA(PrivateKey privateKey, String data) {
        String result = "";
        try {
            //ִ��ǩ��
            Signature signature = Signature.getInstance(SIGNALGORITHMS);
            signature.initSign(privateKey);
            signature.update(data.getBytes());
            byte[] sign = signature.sign();
            return HexUtil.encodeHexString(sign);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * ��ǩ
     * @param publicKey ��Կ
     * @param signed ǩ��
     * @param data ����
     * @return
     */
    public static boolean verifyECDSA(PublicKey publicKey, String signed, String data) {
        try {
            //��֤ǩ��
            Signature signature = Signature.getInstance(SIGNALGORITHMS);
            signature.initVerify(publicKey);
            signature.update(data.getBytes());
            byte[] hex = HexUtil.decode(signed);
            boolean bool = signature.verify(hex);
            // System.out.println("��֤��" + bool);
            return bool;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * ��stringתprivate key
     * @param key ˽Կ���ַ���
     * @return
     * @throws Exception
     */
    public static PrivateKey getPrivateKey(String key) throws Exception {

        byte[] bytes = DatatypeConverter.parseHexBinary(key);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(bytes);
        KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
        return keyFactory.generatePrivate(keySpec);
    }

    /**
     * ��stringתpublicKey
     * @param key ��Կ���ַ���
     * @return
     * @throws Exception
     */
    public static PublicKey getPublicKey(String key) throws Exception {

        byte[] bytes = DatatypeConverter.parseHexBinary(key);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(bytes);
        KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
        return keyFactory.generatePublic(keySpec);
    }


    /**
     * ������Կ��
     * @return
     * @throws Exception
     */
    public static KeyPair getKeyPair() throws Exception {

        ECGenParameterSpec ecSpec = new ECGenParameterSpec(SECP256K1);
        KeyPairGenerator kf = KeyPairGenerator.getInstance(ALGORITHM);
        kf.initialize(ecSpec, new SecureRandom());
        KeyPair keyPair = kf.generateKeyPair();
        return keyPair;
    }
    public static final class HexUtil {
        private static final char[] HEX = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

        public HexUtil() {
        }

        /**
         * byte����ת16�����ַ���
         * @param bytes
         * @return
         */
        public static String encodeHexString(byte[] bytes) {
            int nBytes = bytes.length;
            char[] result = new char[2 * nBytes];
            int j = 0;
            byte[] var4 = bytes;
            int var5 = bytes.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                byte aByte = var4[var6];
                result[j++] = HEX[(240 & aByte) >>> 4];
                result[j++] = HEX[15 & aByte];
            }

            return new String(result);
        }

        /**
         * 16�����ַ���תbyte����
         * @param s �ַ���
         * @return
         */
        public static byte[] decode(CharSequence s) {
            int nChars = s.length();
            if (nChars % 2 != 0) {
                throw new IllegalArgumentException("Hex-encoded string must have an even number of characters");
            } else {
                byte[] result = new byte[nChars / 2];

                for(int i = 0; i < nChars; i += 2) {
                    int msb = Character.digit(s.charAt(i), 16);
                    int lsb = Character.digit(s.charAt(i + 1), 16);
                    if (msb < 0 || lsb < 0) {
                        throw new IllegalArgumentException("Detected a Non-hex character at " + (i + 1) + " or " + (i + 2) + " position");
                    }

                    result[i / 2] = (byte)(msb << 4 | lsb);
                }

                return result;
            }
        }

    }


}

