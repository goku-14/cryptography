package simulation;

import sun.security.ec.ECPrivateKeyImpl;
import sun.security.ec.ECPublicKeyImpl;
import java.math.BigInteger;
import java.security.*;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECFieldFp;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.EllipticCurve;
import java.util.HashMap;
import java.util.Map;

public class testECCDSA {
    public static KeyPair generateECCKeyPair(int keysize) {
        try {
            // ��ȡָ���㷨����Կ��������
            KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
            // ��ʼ����Կ����������ָ����Կ����, ʹ��Ĭ�ϵİ�ȫ�����Դ��
            generator.initialize(keysize);
            // �������һ����Կ��������Կ��˽Կ��
            return generator.generateKeyPair();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static byte[] eccSign(PrivateKey privateKey, byte[] plain) {
        try {
            Signature signature = Signature.getInstance("SHA256withECDSA");
            signature.initSign(privateKey);
            signature.update(plain);
            return signature.sign();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * ��Կ��ǩ
     *
     * @param publicKey ��Կ
     * @param plain     ԭ��
     * @param sign      ǩ��
     * @return
     */
    public static boolean eccVerify(PublicKey publicKey, byte[] plain, byte[] sign) {
        try {
            Signature signature = Signature.getInstance("SHA256withECDSA");
            signature.initVerify(publicKey);
            signature.update(plain);
            return signature.verify(sign);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    public static void main(String[] args) {
        // �����ı�

        // ������Կ��
        int sum1 = 0;
        int sum2 = 0;
        for (int i = 0; i < 1; i++) {
            long start = System.currentTimeMillis();
            KeyPair keyPair = generateECCKeyPair(256);
            PublicKey publicKey = keyPair.getPublic();
            PrivateKey privateKey = keyPair.getPrivate();
            long end = System.currentTimeMillis();
            sum1 += (end-start);
        }
        System.out.println(sum1/1);
        // ǩ����ǩ
        for (int i = 0; i < 1; i++) {
            KeyPair keyPair = generateECCKeyPair(256);
            PublicKey publicKey = keyPair.getPublic();
            PrivateKey privateKey = keyPair.getPrivate();
            randomString rs = new randomString();
            byte[] plain = rs.usingUUID().getBytes();

            long start1 = System.currentTimeMillis();
            byte[] sign = eccSign(privateKey, plain);
            boolean verify = eccVerify(publicKey, plain, sign);
            long end1 = System.currentTimeMillis();
            sum2 += (end1-start1);
        }
        System.out.println(sum2/1);
        //System.err.println(verify);
    }









}

