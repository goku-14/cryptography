package simulation;

import java.security.MessageDigest;

public class hashTest {
    public static void main(String[] args) throws Exception {
        randomString rs = new randomString();
        String originalString1 = rs.usingUUID();
        String originalString2 = rs.usingUUID();
        byte[] result1 = {};
        byte[] result2 = {};
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        messageDigest.update(originalString1.getBytes());
        result1 = messageDigest.digest();
        messageDigest.update(originalString2.getBytes());
        result2 = messageDigest.digest();

        StringBuilder hexString1 = new StringBuilder();
        StringBuilder hexString2 = new StringBuilder();
        StringBuilder combin = new StringBuilder();

        for (byte b : result1) {
            hexString1.append(String.format("%02X", b));
        }
        for (byte b : result2) {
            hexString2.append(String.format("%02X", b));
        }

        String str1 = hexString1.toString();
        String str2 = hexString2.toString();
        int userNum = 15;
        long[] result = new long[20000];
        for (int i = 0; i < 100; i++) {
            long start = System.nanoTime();
            for (int j = 0; j < userNum; j++) {
                String cob = str1 + str2;
                messageDigest.update(cob.getBytes());
                messageDigest.digest();
            }
            long end = System.nanoTime();
            result[i] = end - start;
        }
        long sum = 0;
        for (int i = 0; i < 100; i++) {
            sum += result[i];
        }
        System.out.println("��ϣʱ�䣺" + (double)(sum)/100000000);
    }

}
