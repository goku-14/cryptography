package simulation;
import ecc.CryptoSystem;
import ecc.elliptic.*;
import ecc.*;
public class testBadNode {
    public static void main(String[] args) throws InsecureCurveException {
        EllipticCurve ec = new EllipticCurve(new secp256r1());
        CryptoSystem cs = new ECCryptoSystem(ec);
        TestECCryptoLIU test = new TestECCryptoLIU();
        Key[] keys = test.generation();
        long start = System.currentTimeMillis();

        ECKey temp = (ECKey) keys[1];
        for (int i = 0; i < 256; i++) {
            ec.onCurve(temp.getECPoint());
        }
        long end = System.currentTimeMillis();
        System.out.println(end - start);
    }
}
