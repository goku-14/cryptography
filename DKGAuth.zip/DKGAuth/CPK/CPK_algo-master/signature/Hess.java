package signature;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import simulation.randomString;

import java.lang.reflect.Proxy;

    public class Hess implements Ident{
        private Element s,r,P,Ppub,Su,Qu,W,h,P1,T,TT,T1,T2,W1,W2;
        private Field G1,Zr;
        private Pairing pairing;
        public Hess(){
            init();
        }
        private void init(){
            pairing = PairingFactory.getPairing("a.properties");
            PairingFactory.getInstance().setUsePBCWhenPossible(true);
            checkSymmetric(pairing);
            Zr = pairing.getZr();
            G1 = pairing.getG1();
            Ppub = G1.newElement();
            Su = G1.newElement();
            Qu = G1.newElement();
            W = G1.newElement();
            W1 = G1.newElement();
            W2 = G1.newElement();
            h = Zr.newElement();
            Field GT = pairing.getGT();
            T = GT.newElement();
            T1 = GT.newElement();
            T2 = GT.newElement();
        }
        private void checkSymmetric(Pairing pairing){
            if(!pairing.isSymmetric()){
                throw  new RuntimeException("��Կ���Գ�");
            }
        }
        @Override
        public void buildSystem() {
            //System.out.println("---------ϵͳ�����׶�--------------");
            s = Zr.newRandomElement().getImmutable();
            P = G1.newRandomElement().getImmutable();
            Ppub = P.mulZn(s).getImmutable();
            //System.out.println("P=" + P);
            //System.out.println("s=" + s);
            //System.out.println("Ppub=" + Ppub);
        }
        @Override
        public void extractSecretKey() {
            randomString rs = new randomString();
            String uid = rs.usingUUID();
            long start = System.currentTimeMillis();
            Qu = pairing.getG1().newElement().setFromHash(uid.getBytes(),0,uid.length()).getImmutable();
            Su = Qu.mulZn(s).getImmutable();
            //System.out.println(Qu.toString().length());
            //System.out.println(Su.toString().length());
            long end = System.currentTimeMillis();
            //System.out.println("������Կ��ʱ��"+ (end-start));
            //System.out.println("Qu=" + Qu);
            //System.out.println("Su=" + Su);
        }
        @Override
        public long sign() {
            //System.out.println("---------ǩ���׶�--------------");
            r = Zr.newRandomElement().getImmutable();
            P1 = G1.newRandomElement().getImmutable();
            long start = System.currentTimeMillis();
            T = pairing.pairing(P1,P);
            T = T.powZn(r);
            h = Zr.newRandomElement().getImmutable();//ģ��h = H2(m,T)
            W1 = P1.mulZn(r);
            W2 = Su.mulZn(h);
            W = W2.add(W1);
            long end = System.currentTimeMillis();
            //System.out.println("h=" + h);
            //System.out.println("W=" + W);
            return (end - start);
        }
        @Override
        public long verify() {
            //System.out.println("--------------��֤�׶�------------------");
            long start = System.currentTimeMillis();
            T1 = pairing.pairing(W,P);
            Ppub = Ppub.invert();//��Ppub�ĳ˷���Ԫ
            T2 = pairing.pairing(Qu,Ppub);//Ppubʵ������-Ppub
            T2 = T2.powZn(h);
            TT = T1.mul(T2);
            boolean flag = TT.isEqual(T);
//            if(TT.isEqual(T))
//                System.out.println("T");
//            else
//                System.out.println("F");
            long end = System.currentTimeMillis();
            int byte1 = W.toBytes().length;
            int byte2 = h.toBytes().length;
            return (end - start);
            //System.out.println("ǩ���ĳ���=" + (byte1+byte2));
        }
        public static void main(String[] args){
            long[] time = new long[10000];
            int count = 100;
            long sum1 = 0;
            long sum2 = 0;
            for (int i = 0; i < count; i++) {
                Hess hess = new Hess();
                Ident identProxy =  (Ident) Proxy.newProxyInstance(Hess.class.getClassLoader(),
                        new Class[]{Ident.class},new TimeCountProxyHandle(hess));
                identProxy.buildSystem();
                identProxy.extractSecretKey();
                    sum1 += identProxy.sign();
                    sum2 += identProxy.verify();
            }
            System.out.println(sum1/count);
            System.out.println(sum2/count);
        }
    }


