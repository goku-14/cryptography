package signature;

import org.bouncycastle.asn1.gm.GMNamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.crypto.AsymmetricCipherKeyPair;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.generators.ECKeyPairGenerator;
import org.bouncycastle.crypto.params.ECDomainParameters;
import org.bouncycastle.crypto.params.ECKeyGenerationParameters;
import org.bouncycastle.crypto.params.ECPrivateKeyParameters;
import org.bouncycastle.crypto.params.ECPublicKeyParameters;
import org.bouncycastle.crypto.signers.SM2Signer;
import org.bouncycastle.jcajce.provider.digest.SHA256;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.math.ec.ECPoint;
import org.bouncycastle.util.encoders.Hex;

import java.security.SecureRandom;
import java.security.Security;
import java.util.Arrays;

public class IBC {
    static ECDomainParameters curveParams;
    public static void main(String[] args) {

        Security.addProvider(new BouncyCastleProvider());

        // ����SM2���߲���
        X9ECParameters x9ECParameters = GMNamedCurves.getByName("sm2p256v1");
        curveParams = new ECDomainParameters(x9ECParameters.getCurve(), x9ECParameters.getG(), x9ECParameters.getN());

        try {
            // ������Կ��
            ECKeyPairGenerator keyPairGenerator = new ECKeyPairGenerator();
            keyPairGenerator.init(new ECKeyGenerationParameters(curveParams, new SecureRandom()));
            AsymmetricCipherKeyPair keyPair = keyPairGenerator.generateKeyPair();

            // ��ȡ˽Կ�͹�Կ
            ECPrivateKeyParameters privateKey = (ECPrivateKeyParameters) keyPair.getPrivate();
            ECPublicKeyParameters publicKey = (ECPublicKeyParameters) keyPair.getPublic();

            // ���ݱ�ʶ
            String identity = "Alice";

            // Ҫǩ������Ϣ
            byte[] message = "Hello, IBC Signature!".getBytes();

            // ����ǩ��
            byte[] signature = ibcSign(privateKey, identity, message);

            // ��ӡǩ�����
            System.out.println("Signature: " + Hex.toHexString(Hex.encode(signature)));

            // ��֤ǩ��
            boolean verified = ibcVerify(publicKey, identity, message, signature);

            // ��ӡ��֤���
            System.out.println("Verified: " + verified);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static byte[] ibcSign(ECPrivateKeyParameters privateKey, String identity, byte[] message) {
        try {
            // �������ݱ�ʶ�Ĺ�ϣֵ
            byte[] identityHash = SHA256(identity.getBytes());

            // ʹ�ù�ϣֵ������Բ���ߵ�
            ECPoint identityPoint = curveParams.getCurve().decodePoint(identityHash);

            // ����ǩ��
            SM2Signer signer = new SM2Signer();
            signer.init(true, privateKey);
            signer.update(message, 0, message.length);
            return signer.generateSignature();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static boolean ibcVerify(ECPublicKeyParameters publicKey, String identity, byte[] message, byte[] signature) {
        try {
            // ��֤ǩ��
            SM2Signer verifier = new SM2Signer();
            verifier.init(false, publicKey);
            verifier.update(message, 0, message.length);
            return verifier.verifySignature(signature);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private static byte[] SHA256(byte[] data) {
        try {
            SHA256Digest digest = new SHA256Digest();
            digest.update(data, 0, data.length);
            byte[] hash = new byte[digest.getDigestSize()];
            digest.doFinal(hash, 0);
            return Arrays.copyOf(hash, hash.length / 2);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
