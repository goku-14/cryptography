package signature;

public interface Ident {
    void buildSystem();
    void extractSecretKey();
    long sign();
    long verify();
}

