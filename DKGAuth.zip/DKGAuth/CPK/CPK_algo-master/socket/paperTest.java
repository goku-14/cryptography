package socket;

import ecc.CryptoSystem;
import ecc.Key;
import ecc.elliptic.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class paperTest {
    public static void main(String[] args) throws InsecureCurveException, NoCommonMotherException {
        EllipticCurve ec1 = new EllipticCurve(new secp112r1());
        EllipticCurve ec2 = new EllipticCurve(new secp160r1());
        EllipticCurve ec3 = new EllipticCurve(new secp256r1());
        CryptoSystem cs1 = new ECCryptoSystem(ec1);
        CryptoSystem cs2 = new ECCryptoSystem(ec2);
        CryptoSystem cs3 = new ECCryptoSystem(ec3);

        //String SKpath="sKey.txt";
        //String PKpath="pKey.txt";
        //long start = System.currentTimeMillis();
        long[] temp1 = new long[100];
        long[] temp2 = new long[100];
        long[] temp3 = new long[100];
        double[] res = new double[256];
        long sum1 = 0;
        long sum2 = 0;
        long sum3 = 0;
        int count = 37;
        int round = 100;
        Key sk,pk;
            for (int i = 0; i < round; i++) {
                long start1 = System.currentTimeMillis();
                for (int j = 0; j < count; j++) {
                    sk = cs1.generateKey();
                    pk = sk.getPublic();
                }
                long end1 = System.currentTimeMillis();
                temp1[i] = end1 - start1;

                long start2 = System.currentTimeMillis();
                for (int j = 0; j < count; j++) {
                    sk = cs2.generateKey();
                    pk = sk.getPublic();
                }
                long end2 = System.currentTimeMillis();
                temp2[i] = end2 - start2;

                long start3 = System.currentTimeMillis();
                for (int j = 0; j < count; j++) {
                    sk = cs3.generateKey();
                    pk = sk.getPublic();
                }
                long end3 = System.currentTimeMillis();
                temp3[i] = end3 - start3;
            }
            for (int b = 0; b < round; b++) {
                sum1 += temp1[b];
                sum2 += temp2[b];
                sum3 += temp3[b];
            }
            System.out.println(((double)sum1/round));
            System.out.println(((double)sum2/round));
            System.out.println(((double)sum3/round));









       /* for (int i = 0; i < 8; i++) {
            result[i][0] = (ECKey) cs.generateKey();
            result[i][1] = (ECKey)result[i][0].getPublic();
        }


        KeyOperate kp = new KeyOperate();
        ECKey pkadd = null;
        ECKey skadd = null;
        boolean flag = true;
        skadd = result[0][0];
        pkadd = result[0][1];
        long start1 = System.currentTimeMillis();
        for (int i = 1; i < 8; i++) {
                skadd = (ECKey) kp.KeyCombin(skadd,result[i][0]);
                pkadd = (ECKey) kp.KeyCombin(pkadd,result[i][1]);
            }
        long end1 = System.currentTimeMillis();
        //String m_binary = new BigInteger(skadd.getSk().toByteArray()).toString(2);
        //System.out.println(m_binary.length());
        System.out.println("�����Կʱ�ӣ�" + (end1 - start1) + "ms");*/


    }

}
