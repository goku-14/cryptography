package socket;

import com.zchz.brop.brochain.protocol.core.methods.response.BrochainTransactionReceipt;
import ecc.Key;
import org.example.CURD;
import testBrochain.crudChain;

import java.util.List;
import java.util.Map;

public class deleteChain {
    public static void main(String args[]) throws Exception {

        //��ȡ���ܺ�Լ��ַ
        crudChain crudchain = new crudChain();
        CURD crud = crudchain.crudChain();

        BrochainTransactionReceipt receipt=crud.remove("���빫Կ����2").send();
        //System.out.println(crud.get("liu").send());
        System.out.println("ɾ���ɹ���ɾ����ִΪ��" +receipt);



    }




}
