package socket;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class traceBack {

    public static List<List<Map>> combine(List<Map> nums) {
        List<List<Map>> result = new ArrayList<>();
        backtrack(result, new ArrayList<>(), nums, 0);
        return result;
    }

    private static void backtrack(List<List<Map>> result, List<Map> tempList, List<Map> nums, int start) {
        if (!tempList.isEmpty()) {
            result.add(new ArrayList<>(tempList));
        }
        for (int i = start; i < nums.size(); i++) {
            tempList.add(nums.get(i));
            backtrack(result, tempList, nums, i + 1);
            tempList.remove(tempList.size() - 1);
        }
    }
}
