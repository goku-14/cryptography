package socket;
import ecc.CryptoSystem;
import ecc.Key;
import ecc.elliptic.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
public class generationKey {
    static volatile List<Map> result;
    public Key[] generationKey()throws Exception {

        EllipticCurve ec = new EllipticCurve(new secp160r1());
        CryptoSystem cs = new ECCryptoSystem(ec);

        String[] receiverAddresses = new String[7];
        receiverAddresses[0] = "192.168.15.131";
        receiverAddresses[1] = "192.168.15.130";
        receiverAddresses[2] = "192.168.15.132";
        receiverAddresses[3] = "192.168.15.133";
        receiverAddresses[4] = "192.168.15.134";
        receiverAddresses[5] = "192.168.15.135";
        receiverAddresses[6] = "192.168.15.136";
        result = new ArrayList<>();

        List<SenderThread> senderThreads = new ArrayList<>();

        long start1=System.currentTimeMillis();

        for(String receiveAddress : receiverAddresses){
            SenderThread senderThread = new SenderThread(receiveAddress,result);
            senderThreads.add(senderThread);
            senderThread.start();
        }
        for(SenderThread senderThread : senderThreads){
            senderThread.join();
        }

        //combine keys
        KeyOperate kp = new KeyOperate();
        Key pkadd = null;
        Key skadd = null;
        boolean flag = true;

        for (int i = 0; i < result.size(); i++) {
            Map<String,Key[]> map = result.get(i);
            for (Map.Entry<String,Key[]> entry : map.entrySet()) {
                ECKey temp = (ECKey) entry.getValue()[1];
                if(ec.onCurve(temp.getECPoint())){
                    if(flag){
                        pkadd = entry.getValue()[1];
                        skadd = entry.getValue()[0];
                        flag = false;
                    }
                    else{
                        pkadd = kp.KeyCombin(pkadd,entry.getValue()[1]);
                        skadd = kp.KeyCombin(skadd,entry.getValue()[0]);

                    }
                }
                else {
                    System.out.println("the bad node is:"+entry.getKey());
                }
            }
        }
        long end1 = System.currentTimeMillis();
        //System.out.println("��Կ�������");
        System.out.println("�¹�ԿΪ��"+ pkadd.toString());
        //System.out.println("˽ԿΪ��" + skadd.toString());

        System.out.println("����ʱ��Ϊ��"+(end1-start1)+"ms");
        Key[] res = new Key[2];
        res[0] = skadd;
        res[1] = pkadd;
        return res;

    }
    static class SenderThread extends Thread {
        private String receiveAddress;
        List<Map> result;

        public SenderThread(String receiveAddress, List<Map> result) {
            this.receiveAddress = receiveAddress;
            this.result = result;
        }

        @Override
        public void run() {
            try {
                Socket socket = new Socket(receiveAddress, 54444);
                OutputStream outputStream = socket.getOutputStream();
                String message = "���  i need keys";
                socket.getOutputStream().write(message.getBytes("UTF-8"));
                //ͨ��shutdownOutput���ٷ������Ѿ����������ݣ�����ֻ�ܽ�������
                socket.shutdownOutput();
                // waitting news from server
                InputStream inputStream = socket.getInputStream();

                ObjectInputStream objInputStr = new ObjectInputStream(inputStream);
                Map<String,Key[]> newKey1 = (Map<String,Key[]>) objInputStr.readObject();
                result.add(newKey1);
                objInputStr.close();
                inputStream.close();
                outputStream.close();
                socket.close();

            } catch (UnknownHostException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
