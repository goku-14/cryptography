package socket;
import ecc.CryptoSystem;
import ecc.Key;
import ecc.elliptic.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
public class socketClientTest {
    static volatile List<Map> result;
    public static void main(String args[]) throws Exception {

        EllipticCurve ec = new EllipticCurve(new secp160r1());
        CryptoSystem cs = new ECCryptoSystem(ec);

        String[] receiverAddresses = new String[7];
        receiverAddresses[0] = "192.168.15.131";
        receiverAddresses[1] = "192.168.15.130";
        receiverAddresses[2] = "192.168.15.132";
        receiverAddresses[3] = "192.168.15.133";
        receiverAddresses[4] = "192.168.15.134";
        receiverAddresses[5] = "192.168.15.135";
        receiverAddresses[6] = "192.168.15.136";
        result = new ArrayList<>();

        List<SenderThread> senderThreads = new ArrayList<>();

        long start1=System.currentTimeMillis();

        for(String receiveAddress : receiverAddresses){
            SenderThread senderThread = new SenderThread(receiveAddress,result);
            senderThreads.add(senderThread);
            senderThread.start();
        }
        for(SenderThread senderThread : senderThreads){
            senderThread.join();
        }

        //combine keys
        KeyOperate kp = new KeyOperate();
        Key pkadd = null;
        Key skadd = null;
        boolean flag = true;

        for (int i = 0; i < result.size(); i++) {
            Map<String,Key[]> map = result.get(i);
            for (Map.Entry<String,Key[]> entry : map.entrySet()) {
                ECKey temp = (ECKey) entry.getValue()[1];
                if(ec.onCurve(temp.getECPoint())){
                    if(flag){
                        pkadd = entry.getValue()[1];
                        skadd = entry.getValue()[0];
                        flag = false;
                    }
                    else{
                        pkadd = kp.KeyCombin(pkadd,entry.getValue()[1]);
                        skadd = kp.KeyCombin(skadd,entry.getValue()[0]);

                    }
                }
                else {
                    System.out.println("the bad node is:"+entry.getKey());
                }
            }
        }
        long end1 = System.currentTimeMillis();
        System.out.println("���յ�" + result.size() + "������������Կ����");
        System.out.println("��Կ������");
        System.out.println("���չ�ԿΪ" + pkadd.toString());
        System.out.println("����˽ԿΪ" +skadd.toString());

        System.out.println("final relay��"+(end1-start1)+"ms");

        //testing en/de

        byte[] test1 = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
        byte[] test2 = cs.decrypt(cs.encrypt(test1, 20, pkadd), skadd);

        String string="hello worldx";
        byte[] test=string.getBytes("GBK");
        String t1=new String(test,"GBK");
        String ten=new String(cs.encrypt(test1,test.length,skadd),"GBK");
        //System.out.println("hhh: "+ten);
        String tde=new String(cs.decrypt(cs.encrypt(test, test.length, pkadd), skadd),"GBK");

        if(Arrays.equals(test1, test1)) System.out.println("���������ɹ�˽Կ...");
        if(Arrays.equals(test1, test2)) {
            System.out.println("����Ϊ : "+t1);
            System.out.println("���ܺ�����Ϊ: "+ten);
            System.out.println("���ܺ�����Ϊ: "+tde);
            System.out.println("�ӽ��ܳɹ�����������������");
        } else {
            System.out.print("Fail\n{");

        }

    }
    static class SenderThread extends Thread {
        private String receiveAddress;
        List<Map> result;

        public SenderThread(String receiveAddress, List<Map> result) {
            this.receiveAddress = receiveAddress;
            this.result = result;
        }

        @Override
        public void run() {
            try {
                Socket socket = new Socket(receiveAddress, 54444);
                OutputStream outputStream = socket.getOutputStream();
                String message = "���  i am UID_A,i need keys";
                socket.getOutputStream().write(message.getBytes("UTF-8"));
                //ͨ��shutdownOutput���ٷ������Ѿ����������ݣ�����ֻ�ܽ�������
                socket.shutdownOutput();
                // waitting news from server
                InputStream inputStream = socket.getInputStream();

                ObjectInputStream objInputStr = new ObjectInputStream(inputStream);
                Map<String,Key[]> newKey1 = (Map<String,Key[]>) objInputStr.readObject();
                result.add(newKey1);
                objInputStr.close();
                inputStream.close();
                outputStream.close();
                socket.close();

            } catch (UnknownHostException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }
}