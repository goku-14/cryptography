package ecc.elliptic;

import ecc.*;
import ecc.io.*;
import java.io.*;
import java.math.BigInteger;
import java.util.*;
public class TestECCryptoLIU {
    public Key[] generation() {
        try {
            EllipticCurve ec = new EllipticCurve(new secp160r1());
            CryptoSystem cs = new ECCryptoSystem(ec);
            Key[] newKey = new Key[2];

            //String SKpath="sKey.txt";
            //String PKpath="pKey.txt";

            long start1 = System.currentTimeMillis();
            Key sk = (ECKey) cs.generateKey();
            long end1 = System.currentTimeMillis();
            Key pk = sk.getPublic();
            System.out.println("������Կʱ�ӣ�" + (end1 - start1) + "ms");
            newKey[0] = sk;
            newKey[1] = pk;
            return newKey;


        } catch (InsecureCurveException e) {
            throw new RuntimeException(e);
        }
    }
}
