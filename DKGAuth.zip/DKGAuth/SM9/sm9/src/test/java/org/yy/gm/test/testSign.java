package org.yy.gm.test;

//import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;
import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;
import org.w3c.dom.ls.LSOutput;
import org.yy.gm.SM9LogUtils;
import org.yy.gm.structs.SM9SignMasterKeyPair;
import org.yy.gm.structs.SM9SignPrivateKey;
import org.yy.gm.structs.SM9Signature;
import org.yy.gm.test.engines.SM9SignerTest;
import org.yy.gm.test.generators.SM9MasterKeyPairGeneratorTest;

import java.math.BigInteger;

public class testSign {
    public static void test_standard_sm9_sign(SM9WithStandardTest sm9) {
        SM9LogUtils.showMsg("\n----------------------------------------------------------------------\n");
        SM9LogUtils.showMsg("SM9签名测试\n");
        String id_A = "Alice";
        //SM9LogUtils.showMsg("签名主密钥和用户签名私钥产生过程中的相关值:");
        // 生成签名主密钥对
        SM9MasterKeyPairGeneratorTest.k = new BigInteger("0130E78459D78545CB54C587E02CF480CE0B66340F319F348A1D5B1F2DC5F4", 16);
        SM9SignMasterKeyPair keyPair = sm9.genSignMasterKeyPair();
        //SM9LogUtils.showMsg("签名主私钥 ks:");
        //SM9LogUtils.showMasterPrivateKey(keyPair.getPrivate());
        //SM9LogUtils.showMsg("签名主公钥 Ppub-s:");
        //SM9LogUtils.showMasterPublicKey(keyPair.getPublic());
        // 显示ID信息
        //SM9LogUtils.showMsg("实体A的标识IDA:");
        //SM9LogUtils.showMsg(id_A);
        //SM9LogUtils.showMsg("IDA的16进制表示");
        //SM9LogUtils.showMsg(SM9LogUtils.toHexString(id_A.getBytes()));
        long start1 = System.currentTimeMillis();
        // 生成签名私钥
        //SM9LogUtils.showMsg("签名私钥 ds_A:");
        SM9SignPrivateKey privateKey = sm9.genSignPrivateKey(keyPair.getPrivate(), id_A);
        //SM9LogUtils.showPrivateKey(privateKey);
        long end1 = System.currentTimeMillis();
        //System.out.println("生成签名私钥时间：" + (end1-start1));

        byte[] data = "Chinese IBS standard".getBytes();

        // 签名

        //SM9LogUtils.showMsg("签名步骤中的相关值:");
        String msg = "Chinese IBS standard";
        //SM9LogUtils.showMsg("待签名消息 M:");
        //SM9LogUtils.showMsg(msg);
        //SM9LogUtils.showMsg("M的16进制表示");
        //SM9LogUtils.showMsg(SM9LogUtils.toHexString(msg.getBytes()));
        SM9SignerTest.r = new BigInteger("033C8616B06704813203DFD00965022ED15975C662337AED648835DC4B1CBE", 16);
        for (int k = 0; k < 55; k += 5) {
            int count = k;
            long sum1 = 0;
            long sum2 = 0;
            int round = 100;
            SM9Signature signature;
            for (int i = 0; i < round; i++) {
                long start2 = System.currentTimeMillis();
                for (int j = 0; j < count; j++) {
                    signature = sm9.sign(privateKey, data);
                }
                long end2 = System.currentTimeMillis();
                sum1 += (end2-start2);
            }
            System.out.println("用户为"+ k +"的签名时间为：" + sum1/round);
            signature = sm9.sign(privateKey, data);
            //SM9LogUtils.showResultSignature(signature);
            //System.out.println(signature);
            //System.out.println("签名长度为：" + signature.toByteArray().length);
            // 验签
            for (int i = 0; i < round; i++) {
                long start3 = System.currentTimeMillis();
                for (int j = 0; j < count; j++) {
                    sm9.verify(keyPair.getPublic(), id_A, data, signature);
                    SM9SignPrivateKey privateKey1 = sm9.genSignPrivateKey(keyPair.getPrivate(), id_A);
                }
                long end3 = System.currentTimeMillis();
                sum2 += (end3-start3);
            }
            System.out.println("用户为"+ k +"验签时间为：" + sum2/round);

        }

        //SM9LogUtils.showMsg("验证步骤中的相关值:");
    }




    public static void main(String[] args) {
        testSign test = new testSign();
        test.test_standard_sm9_sign(new SM9WithStandardTest());
    }
}
