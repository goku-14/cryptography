package org.yy.gm.test.engines;

import org.yy.gm.SM9LogUtils;
import org.yy.gm.structs.SM9SignMasterKeyPair;
import org.yy.gm.structs.SM9SignPrivateKey;
import org.yy.gm.structs.SM9Signature;
import org.yy.gm.test.SM9WithStandardTest;
import org.yy.gm.test.generators.SM9MasterKeyPairGeneratorTest;
import org.yy.gm.test.testSign;

import java.math.BigInteger;

public class testKeyGeneration {
    public static void test_standard_sm9_sign(SM9WithStandardTest sm9) {
        SM9LogUtils.showMsg("\n----------------------------------------------------------------------\n");
        SM9LogUtils.showMsg("SM9签名测试\n");
        String id_A = "Alice";
        SM9MasterKeyPairGeneratorTest.k = new BigInteger("0130E78459D78545CB54C587E02CF480CE0B66340F319F348A1D5B1F2DC5F4", 16);
        SM9SignMasterKeyPair keyPair = sm9.genSignMasterKeyPair();
        int round = 100;
        int userNum = 50;
        long sum = 0;
        for (int k = 0; k <= userNum; k += 5) {
            for (int i = 0; i < round; i++) {
                long start1 = System.currentTimeMillis();
                for (int j = 0; j < k; j++) {
                    SM9SignPrivateKey privateKey = sm9.genSignPrivateKey(keyPair.getPrivate(), id_A);
                    keyPair.getPrivate();
                }
                long end1 = System.currentTimeMillis();
                sum += (end1 - start1);
            }
            System.out.println("用户数量为"+ k +"用时为" + sum/100);

        }



        //System.out.println("生成签名私钥时间：" + (end1-start1));



    }




    public static void main(String[] args) {
        testKeyGeneration test = new testKeyGeneration();
        test.test_standard_sm9_sign(new SM9WithStandardTest());
    }
}
